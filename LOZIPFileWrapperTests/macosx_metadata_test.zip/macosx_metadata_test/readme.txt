2007-10.
This dir contains 2 jpg files:

catty_with_no_resource.jpg
catty_with_resource.jpg

One of them has resource fork.
